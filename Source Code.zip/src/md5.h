#pragma once
int UpdateFile(const wchar_t* localFile, const wchar_t* remoteURL);
